﻿namespace WebApplication2.Controllers
{
    internal class Location
    {
    }
}