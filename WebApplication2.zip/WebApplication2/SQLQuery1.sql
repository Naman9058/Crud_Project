﻿select * from locations;
select * from Customers;

insert into locations values
('noida','this is best place'),
('dhampur','this is best place'),
('G.noida','this is best place'),
('delhi','this is best place'),
('merat','this is best place')

insert into Customers values
('ajay kumar','ajay@gmail.com','7676543424',1),
('sumit kumar','sumit@gmail.com','9584671235',2),
('kamal kumar','kamak@gmail.com','7678954698',3),
('parul kumar','parul@gmail.com','7784592144',4),
('vikas kumar','vikas@gmail.com','7676458796',5)


